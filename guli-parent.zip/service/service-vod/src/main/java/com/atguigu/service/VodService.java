package com.atguigu.service;

import org.springframework.web.multipart.MultipartFile;

/**
 * @Description
 */
public interface VodService {
    String uploadVideoALY(MultipartFile file);
}
