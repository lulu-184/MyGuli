package com.atguigu.oss.service;

import org.springframework.web.multipart.MultipartFile;

/**
 * @Description
 */
public interface OssService {

    String uploadFileAvatar(MultipartFile file);
}
