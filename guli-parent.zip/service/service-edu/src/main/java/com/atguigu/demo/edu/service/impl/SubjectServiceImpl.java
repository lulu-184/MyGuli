package com.atguigu.demo.edu.service.impl;

import com.alibaba.excel.EasyExcel;
import com.atguigu.demo.edu.entity.Subject;
import com.atguigu.demo.edu.entity.excel.SubjectData;
import com.atguigu.demo.edu.entity.subject.OneSubject;
import com.atguigu.demo.edu.entity.subject.TwoSubject;
import com.atguigu.demo.edu.listener.SubjectExcelListener;
import com.atguigu.demo.edu.mapper.SubjectMapper;
import com.atguigu.demo.edu.service.SubjectService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.apache.ibatis.annotations.One;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 课程科目 服务实现类
 * </p>
 *
 * @author testjava
 * @since 2022-08-09
 */
@Service
public class SubjectServiceImpl extends ServiceImpl<SubjectMapper, Subject> implements SubjectService {
    //添加课程分类
    @Override
    public void saveSubject(MultipartFile file,SubjectService subjectService) {
        try {
            //文件输入流
            InputStream inputStream = file.getInputStream();
            //调用方法进行读取
            EasyExcel.read(inputStream, SubjectData.class,new SubjectExcelListener(subjectService))
                            .sheet().doRead();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public List<OneSubject> getAllOneTwoSubject() {
        //1 查询所有一级分类
        QueryWrapper<Subject> oneSubjectQueryWrapper = new QueryWrapper<>();
        oneSubjectQueryWrapper.eq("parent_id", "0");

        List<Subject> oneSubjectList = baseMapper.selectList(oneSubjectQueryWrapper);


        //2 查询所有二级分类
        QueryWrapper<Subject> twoSubjectQueryWrapper = new QueryWrapper<>();
        twoSubjectQueryWrapper.ne("parent_id", "0");

        List<Subject> twoSubjectList = baseMapper.selectList(twoSubjectQueryWrapper);

        //创建list集合，存储最终封装的数据
        List<OneSubject> finalSubjectList = new ArrayList<>();
        //3 封装一级分类
        // 查询出来所有的一级分类list集合遍历，得到每个一级分类对象，获取每个一级分类对家值，
        for (int i = 0; i < oneSubjectList.size(); i++) {//遍历集合
            Subject subject = oneSubjectList.get(i);

            //把subject的值获取出来，放到OneSubject对象里面

            //多个放到OneSubject对象里面放到finalSubjectList里面
            OneSubject oneSubject = new OneSubject();
            BeanUtils.copyProperties(subject,oneSubject);

            finalSubjectList.add(oneSubject);
            //4 封装二级分类
            //在一级分类循环遍历查询所有的二级分类
            List<TwoSubject> twoFinalSubjectList = new ArrayList<>();

            //遍历二级分类list集合
            for (int m = 0; m < twoSubjectList.size(); m++) {
                Subject tSubject = twoSubjectList.get(m);

                //判断二级分类parentid和一级分类id是否一样
                if(tSubject.getParentId().equals(oneSubject.getId())){
                    TwoSubject twoSubject = new TwoSubject();
                    BeanUtils.copyProperties(tSubject,twoSubject);
                    twoFinalSubjectList.add(twoSubject);
                }
            }
            oneSubject.setChildren(twoFinalSubjectList);

        }
        return finalSubjectList;
    }
}
