package com.atguigu.demo.edu.mapper;

import com.atguigu.demo.edu.entity.Subject;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 课程科目 Mapper 接口
 * </p>
 *
 * @author testjava
 * @since 2022-08-09
 */
public interface SubjectMapper extends BaseMapper<Subject> {

}
