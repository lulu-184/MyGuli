package com.atguigu.demo.edu.controller;


import com.atguigu.commonutils.R;
import com.atguigu.demo.edu.entity.Course;
import com.atguigu.demo.edu.entity.vo.CourseInfoVo;
import com.atguigu.demo.edu.entity.vo.CoursePublishVo;
import com.atguigu.demo.edu.entity.vo.CourseQuery;
import com.atguigu.demo.edu.service.CourseService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 课程 前端控制器
 * </p>
 *
 * @author testjava
 * @since 2022-08-11
 */
@Api(description = "课程信息添加")
@RestController
@RequestMapping("/edu/course")
@CrossOrigin
public class CourseController {
    @Autowired
    private CourseService courseService;

    //课程列表 TODO
    //完善条件查询带分页
    @GetMapping
    public R getCourseList() {
        List<Course> list = courseService.list(null);
        return R.ok().data("list",list);
    }
    //添加课程基本信息的方法
    @PostMapping("addCourseInfo")
    public R addCourseInfo(@RequestBody CourseInfoVo courseInfoVo){
        String id = courseService.saveCourseInfo(courseInfoVo);
        return R.ok().data("courseId",id);
    }


    //根据课程id查询课程基本信息
    @GetMapping("getCourseInfo/{courseId}")
    public R getCourseInfo(@PathVariable String courseId) {
        CourseInfoVo courseInfoVo = courseService.getCourseInfo(courseId);
        return R.ok().data("courseInfoVo",courseInfoVo);
    }

    //修改课程信息
    @PostMapping("updateCourseInfo")
    public R updateCourseInfo(@RequestBody CourseInfoVo courseInfoVo) {
        courseService.updateCourseInfo(courseInfoVo);
        return R.ok();
    }
    //根据课程id查询课程信息
    @GetMapping("getPublishCourseInfo/{id}")
    public R getPublishCourseInfo(@PathVariable String id) {
        CoursePublishVo coursePublishVo=courseService.pulishCourseInfo(id);
        return R.ok().data("publishCourse",coursePublishVo);
    }

    //课程最终发布
    //修改课程状态
    @PostMapping("publishCourse/{id}")
    public R publishCourse(@PathVariable String id) {
        Course course = new Course();
        course.setId(id);
        course.setStatus("Normal");//设置课程发布状态
        courseService.updateById(course);
        return R.ok();
    }

    //删除课程
    @DeleteMapping("{id}")
    public R deleteCourse(@PathVariable String id) {
        courseService.removeCourse(id);
        return R.ok();
    }

    // 条件分页查询
    @PostMapping("pageCourseCondition/{current}/{limit}")
    public R pageCourseCondition(@PathVariable long current, @PathVariable long limit,
                                 @RequestBody(required = false) CourseQuery courseQuery){
        //创建page对象
        Page<Course> coursePage = new Page<>(current,limit);

        //构建条件
        QueryWrapper<Course> wrapper = new QueryWrapper<>();
        String title=courseQuery.getTitle();
        Integer status=courseQuery.getStatus();
        String statusStr;
        if(!StringUtils.isEmpty(title)){
            wrapper.like("title", title);
        }
        if (!StringUtils.isEmpty(status)){
            if(1==status){
                statusStr="Normal";
            }else {
                statusStr="Draft";
            }
            wrapper.eq("status", statusStr);
        }
        IPage<Course> courseIPage = courseService.page(coursePage, wrapper);
        long total=courseIPage.getTotal();
        List<Course> records = courseIPage.getRecords();
        return R.ok().data("total",total).data("rows",records);

    }

}

