package com.atguigu.demo.edu.service;

import com.atguigu.demo.edu.entity.Teacher;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 讲师 服务类
 * </p>
 *
 * @author testjava
 * @since 2022-07-28
 */
public interface TeacherService extends IService<Teacher> {

}
