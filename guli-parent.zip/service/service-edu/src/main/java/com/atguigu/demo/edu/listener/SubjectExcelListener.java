package com.atguigu.demo.edu.listener;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.atguigu.demo.edu.entity.Subject;
import com.atguigu.demo.edu.entity.excel.SubjectData;
import com.atguigu.demo.edu.service.SubjectService;
import com.atguigu.servicebase.exceptionhandler.GuliException;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;

/**
 * @Description
 */
public class SubjectExcelListener extends AnalysisEventListener<SubjectData> {

    public SubjectService subjectService;

    public SubjectExcelListener() { }

    public SubjectExcelListener(SubjectService subjectService) {
        this.subjectService = subjectService;
    }


    // 读取excel内容，一行一行进行读取
    @Override
    public void invoke(SubjectData subjectData, AnalysisContext analysisContext) {
        if(subjectData == null) {
            throw  new GuliException(20001,"数据为空");
        }

        // 一行一行读取，每次读取有两个值，第一个值一级分类，第二个值二级分类
        //判断一级分类是够重复
        Subject OneSubject = this.existOneSubect(subjectService, subjectData.getOneSubjectName());
        if(OneSubject == null) { // 没有相同一级分类，进行添加
            OneSubject = new Subject();
            OneSubject.setParentId("0");
            OneSubject.setTitle(subjectData.getOneSubjectName());
            subjectService.save(OneSubject);
        }
        //获取一级分类id值
        String pid = OneSubject.getId();

        //添加二级分类
        //判断二级分类是否重复
        Subject TwoSubject = this.existTwoSubect(subjectService, subjectData.getTwoSubjectName(), pid);
        if(TwoSubject == null) {
            TwoSubject = new Subject();
            TwoSubject.setParentId(pid);
            TwoSubject.setTitle(subjectData.getTwoSubjectName());//二级分类名称
            subjectService.save(TwoSubject);
        }

    }

    // 判断一级分类不能重复添加
    private Subject existOneSubect(SubjectService subjectService,String name) {
        QueryWrapper<Subject> wrapper = new QueryWrapper<>();
        wrapper.eq("title", name);
        wrapper.eq("parent_id", "0");
        Subject one = subjectService.getOne(wrapper);
        return one;
    }

    // 判断二级分类不能重复添加
    private Subject existTwoSubect(SubjectService subjectService,String name,String pid) {
        QueryWrapper<Subject> wrapper = new QueryWrapper<>();
        wrapper.eq("title", name);
        wrapper.eq("parent_id", pid);
        Subject two = subjectService.getOne(wrapper);
        return two;
    }
    @Override
    public void doAfterAllAnalysed(AnalysisContext analysisContext) {

    }
}
