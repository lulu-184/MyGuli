package com.atguigu.demo.edu.service;

import com.atguigu.demo.edu.entity.Course;
import com.atguigu.demo.edu.entity.vo.CourseInfoVo;
import com.atguigu.demo.edu.entity.vo.CoursePublishVo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 课程 服务类
 * </p>
 *
 * @author testjava
 * @since 2022-08-11
 */
public interface CourseService extends IService<Course> {

    String saveCourseInfo(CourseInfoVo courseInfoVo);

    CourseInfoVo getCourseInfo(String courseId);

    void updateCourseInfo(CourseInfoVo courseInfoVo);

    CoursePublishVo pulishCourseInfo(String id);

    void removeCourse(String id);
}
