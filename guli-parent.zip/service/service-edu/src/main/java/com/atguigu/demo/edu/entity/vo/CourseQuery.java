package com.atguigu.demo.edu.entity.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description
 */
@ApiModel(value = "Course查询对象", description = "课程查询对象封装")
@Data
public class CourseQuery {
    @ApiModelProperty(value = "课程,模糊查询")
    private String title;

    @ApiModelProperty(value = "头衔 1高级讲师 2首席讲师")
    private Integer status;

}
