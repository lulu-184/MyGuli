package com.atguigu.demo.edu.entity.chapter;

import lombok.Data;

/**
 * @Description
 */
@Data
public class VideoVo {
    private String id;

    private String title;
}
