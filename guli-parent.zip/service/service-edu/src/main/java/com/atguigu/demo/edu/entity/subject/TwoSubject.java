package com.atguigu.demo.edu.entity.subject;

import lombok.Data;

/**
 * @Description
 */
@Data
public class TwoSubject {
    private String id;

    private String title;
}
