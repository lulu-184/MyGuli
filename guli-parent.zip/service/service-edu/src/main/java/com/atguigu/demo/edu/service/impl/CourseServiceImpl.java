package com.atguigu.demo.edu.service.impl;

import com.atguigu.commonutils.R;
import com.atguigu.demo.edu.entity.Course;
import com.atguigu.demo.edu.entity.CourseDescription;
import com.atguigu.demo.edu.entity.vo.CourseInfoVo;
import com.atguigu.demo.edu.entity.vo.CoursePublishVo;
import com.atguigu.demo.edu.entity.vo.CourseQuery;
import com.atguigu.demo.edu.mapper.CourseMapper;
import com.atguigu.demo.edu.service.ChapterService;
import com.atguigu.demo.edu.service.CourseDescriptionService;
import com.atguigu.demo.edu.service.CourseService;
import com.atguigu.demo.edu.service.VideoService;
import com.atguigu.servicebase.exceptionhandler.GuliException;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

/**
 * <p>
 * 课程 服务实现类
 * </p>
 *
 * @author testjava
 * @since 2022-08-11
 */
@Service
public class CourseServiceImpl extends ServiceImpl<CourseMapper, Course> implements CourseService {
    @Autowired
    private CourseDescriptionService courseDescriptionService;

    @Autowired
    private VideoService videoService;

    @Autowired
    private ChapterService chapterService;


    @Override
    public String saveCourseInfo(CourseInfoVo courseInfoVo) {
        // 1 向课程表添加课程基本信息
        // CourseInfoVo转换为eduCourse对象
        Course course = new Course();
        BeanUtils.copyProperties(courseInfoVo,course);
        int insert = baseMapper.insert(course);

        if(insert <= 0){
            throw new GuliException(20001,"添加课程信息失败");
        }

        String cid=course.getId();
        // 2 向课程简介表添加课程简介
        CourseDescription courseDescription = new CourseDescription();
        courseDescription.setDescription(courseInfoVo.getDescription());
        // 设置描述id就是课程id
        courseDescription.setId(cid);
        courseDescriptionService.save(courseDescription);

        return cid;
    }

    @Override
    public CourseInfoVo getCourseInfo(String courseId) {
        // 1 查询课程表
        Course course = baseMapper.selectById(courseId);

        CourseInfoVo courseInfoVo = new CourseInfoVo();
        BeanUtils.copyProperties(course, courseInfoVo);
        // 2 查询描述表
        CourseDescription courseDescription = courseDescriptionService.getById(course);
        courseInfoVo.setDescription(courseDescription.getDescription());
        return courseInfoVo;
    }


    @Override
    public void updateCourseInfo(CourseInfoVo courseInfoVo) {
        //1 修改课程表
        Course course = new Course();
        BeanUtils.copyProperties(courseInfoVo, course);
        int update = baseMapper.updateById(course);
        if(update == 0) {
            throw new GuliException(20001,"修改课程信息失败");
        }

        //2 修改描述表
        CourseDescription description = new CourseDescription();
        BeanUtils.copyProperties(courseInfoVo, description);
        courseDescriptionService.updateById(description);
    }

    @Override
    public CoursePublishVo pulishCourseInfo(String id) {
        // 调用mapper
        CoursePublishVo publishCourseInfo = baseMapper.getPublishCourseInfo(id);
        return publishCourseInfo;
    }

    @Override
    public void removeCourse(String courseId) {
        // 根据课程id删除小节
        videoService.removeVideoByCourseId(courseId);

        // 根据课程id删除章节
        chapterService.removeChapterByCourseId(courseId);

        // 根据课程id删除描述
        courseDescriptionService.removeById(courseId);

        // 根据课程id删除课程本身
        int result = baseMapper.deleteById(courseId);
        if(result == 0) {
            throw  new GuliException(20001,"删除失败");
        }

    }


}
