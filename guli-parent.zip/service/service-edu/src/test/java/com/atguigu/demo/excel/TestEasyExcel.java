package com.atguigu.demo.excel;

import com.alibaba.excel.EasyExcel;

import java.util.ArrayList;
import java.util.List;

/**
 * @Description
 */
public class TestEasyExcel {
    public static void main(String[] args) {
//        //实现excel写的操作
//        //1 设置写入文件加地址和excel名称
//        String filename="D:\\write.xlsx";
//
//        //2 调用easyexcel里面的方法实现写的操作
//        EasyExcel.write(filename,DemoData.class)//路径名称，实体类的class
//                .sheet("学生列表").doWrite(getData());

        //读操作
        String filename="D:\\write.xlsx";

        EasyExcel.read(filename,DemoData.class,new ExcelListener()).sheet().doRead();
    }
    //创建方法返回list集合
    private static List<DemoData> getData(){
        List<DemoData> list = new ArrayList<>();
        for (int i = 0; i < 10;i++){
            DemoData data = new DemoData();
            data.setSno(i);
            data.setSname("jack"+i);
            list.add(data);
        }
        return list;
    }
}
