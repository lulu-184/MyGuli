package com.atguigu.demo;

import com.atguigu.demo.edu.entity.Teacher;
import com.atguigu.demo.edu.entity.subject.OneSubject;
import com.atguigu.demo.edu.mapper.TeacherMapper;
import com.atguigu.demo.edu.service.SubjectService;
import com.atguigu.demo.edu.service.TeacherService;
import com.atguigu.demo.edu.service.impl.SubjectServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

/**
 * @Description
 */
@SpringBootTest
@RunWith(JUnit4.class)
public class test {

    @Autowired
    private TeacherService teacherService;
    @Autowired
    private TeacherMapper teacherMapper;
    @Autowired
    private SubjectService subjectService= new SubjectServiceImpl();
    @Test
    public void add(){
            Teacher teacher = new Teacher();
            teacher.setName("user01");
            int insert = teacherMapper.insert(teacher);
            System.err.println(insert);

    }

    @Test
    public void test(){
        List<OneSubject> list = subjectService.getAllOneTwoSubject();

    }
}
