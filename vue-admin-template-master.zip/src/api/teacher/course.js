import request from '@/utils/request'
// 封装了一些axios的方法

export default {

  // 1  添加课程信息
  addCourseInfo(courseInfo) {
    return request({
      url: `/edu/course/addCourseInfo`, // 注意是着重符
      method: 'post',
      // teacherQuery条件对象，后端使用RequestBody获取数据
      // data表示把对象转换成json进行传递到接口里面
      data: courseInfo
    })
  },
  // 2 查询所有讲师
  getListTeacher() {
    return request({
      url: `/edu/teacher/findAll`, // 注意是着重符
      method: 'get'
    })
  },
  // 3 根据课程id查询课程基本信息
  getCourseInfoId(id) {
    return request({
      url: `/edu/course/getCourseInfo/${id}`, // 注意是着重符
      method: 'get'
    })
  },

  // 4 修改课程信息
  updateCourseInfo(courseInfo) {
    return request({
      url: `/edu/course/updateCourseInfo`, // 注意是着重符
      method: 'post',
      data: courseInfo
    })
  },

  // 5 最终发布课程确认信息
  getPulishCourseInfo(id) {
    return request({
      url: `/edu/course/getPublishCourseInfo/${id}`, // 注意是着重符
      method: 'get'
    })
  },

  // 课程最终发布
  publishCourse(id) {
    return request({
      url: `/edu/course/publishCourse/${id}`, // 注意是着重符
      method: 'post'
    })
  },

  // 查询课程列表
  getCourseList() {
    return request({
      url: `/edu/course`, // 注意是着重符
      method: 'get'
    })
  },

  // 删除课程
  deleteCourseById(id) {
    return request({
      url: `/edu/course/${id}`, // 注意是着重符
      method: 'delete'
    })
  },

  // 分页查询
  pageCourseCondition(current, limit, courseQuery) {
    return request({
      url: `/edu/course/pageCourseCondition/${current}/${limit}`, // 注意是着重符
      method: 'post',
      data: courseQuery
    })
  }
}

