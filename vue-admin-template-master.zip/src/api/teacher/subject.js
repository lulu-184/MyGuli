import request from '@/utils/request'
// 封装了一些axios的方法

export default {
  getSubjectList() {
    return request({
      url: `/edu/subject/getAllSubject`, // 注意是着重符
      method: 'get'
    })
  }
}

