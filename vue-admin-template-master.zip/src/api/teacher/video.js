import request from '@/utils/request'
// 封装了一些axios的方法

export default {

  // getAllChapterVideo(courseId) {
  //   return request({
  //     url: `/edu/chapter/getChapterVideo/${courseId}`, // 注意是着重符
  //     method: 'get'
  //   })
  // },
  // 添加小节
  addVideo(video) {
    return request({
      url: `/edu/video/addVideo`, // 注意是着重符
      method: 'post',
      data: video
    })
  },
  // 查询小节信息
  getVideoInfoById(videoId) {
    return request({
      url: `/edu/video/getVideoInfoById/${videoId}`, // 注意是着重符
      method: 'get'
    })
  },
  // 修改小节
  updateVideoById(video) {
    return request({
      url: `/edu/video/updateVideo`, // 注意是着重符
      method: 'post',
      data: video
    })
  },
  // 删除小节
  deleteVideo(videoId) {
    return request({
      url: `/edu/video/${videoId}`, // 注意是着重符
      method: 'delete'
    })
  }

}

