import request from '@/utils/request'
// 封装了一些axios的方法

export default {

  // 1  讲师列表（条件查询分页）
  // current当前页 limit每页记录数 teacherQuery条件对象
  getTeacherListPage(current, limit, teacherQuery) {
    return request({
      url: `/edu/teacher/pageTeacherCondition/${current}/${limit}`, // 注意是着重符
      method: 'post',
      // teacherQuery条件对象，后端使用RequestBody获取数据
      // data表示把对象转换成json进行传递到接口里面
      data: teacherQuery
    })
  },
  deleteTeacherId(id) {
    return request({
      url: `/edu/teacher/${id}`,
      method: 'delete'
    })
  },
  // 添加讲师
  addTeacher(teacher) {
    return request({
      url: `/edu/teacher/addTeacherBody`,
      method: 'post',
      data: teacher
    })
  },
  // 根据id查询讲师
  getTeacherInfo(id) {
    return request({
      url: `/edu/teacher/getTeacher/${id}`,
      method: 'get'
    })
  },
  // 修改讲师
  updateTeacher(teacher) {
    return request({
      url: `/edu/teacher/updateTeacher`,
      method: 'post',
      data: teacher
    })
  }
}

