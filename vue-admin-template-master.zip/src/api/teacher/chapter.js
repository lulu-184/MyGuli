import request from '@/utils/request'
// 封装了一些axios的方法

export default {

  getAllChapterVideo(courseId) {
    return request({
      url: `/edu/chapter/getChapterVideo/${courseId}`, // 注意是着重符
      method: 'get'
    })
  },
  // 添加章节
  addChapter(chapter) {
    return request({
      url: `/edu/chapter/addChapter`, // 注意是着重符
      method: 'post',
      data: chapter
    })
  },
  // 根据id查询章节
  getChapterInfo(chapterId) {
    return request({
      url: `/edu/chapter/getChapterInfo/${chapterId}`, // 注意是着重符
      method: 'get'
    })
  },
  // 更新章节
  updateChapter(chapter) {
    return request({
      url: `/edu/chapter/updateChapter`, // 注意是着重符
      method: 'post',
      data: chapter
    })
  },
  // 删除章节
  deleteChapter(chapterId) {
    return request({
      url: `/edu/chapter/${chapterId}`, // 注意是着重符
      method: 'delete'
    })
  }

}

